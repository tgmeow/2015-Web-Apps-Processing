Draws a random tessalation and samples a pie chunk of it and redraws it in a circle to create a kaleidoscope effect.

On my honor I did not give or receive unauthorized aid on this assignment.

Tiger Mou