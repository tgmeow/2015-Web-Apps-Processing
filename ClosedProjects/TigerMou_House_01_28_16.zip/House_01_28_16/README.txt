/* @title:   House_01_28_16
 * Class:   Web Apps 2016 2nd Semester 1:00 
 * @author:  Tiger Mou
 * Description: This program draws a house with two trees, a ground, and a shaking sun.
 *              The house, trees, and ground rotate around the center of the sun.
 */
This program draws a nice little house that rotates around the sun. The rotation speed depends on the x mouse location.

The house is made of a triangular roof, and rectangular windows, body, and door.
There are two trees on the side made of an ellipse and a rectangle.
The sun is made up of a gradient of colors and randomly shakes.

On my honor I did not give or receive unauthorized assistance on this assignment.

Tiger Mou