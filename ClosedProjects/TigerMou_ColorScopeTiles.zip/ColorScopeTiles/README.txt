Randomly generates three tessalations and draws them with rotation.

On my honor I did not give or receive unauthorized aid on this assignment.

Tiger Mou