Tiger Mou

On my honor I did not give or receive unauthorized aid on this assignment.

This wordle generates randomly placed randomly rotated and randomly colored words along a spiral path.
It reads in a text file (wordleText.txt) and uses the 50 most common words (with a few "dumb" words taken out).
This wordle program uses the drag and zoom feature (work in progress).