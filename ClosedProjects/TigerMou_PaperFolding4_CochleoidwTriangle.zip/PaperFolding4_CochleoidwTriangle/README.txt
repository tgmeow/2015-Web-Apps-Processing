Draws a cochleoid using a moving triangle. (moves the triangle in the path of a cochleoid)

On my honor I did not give or receive unauthorized aid on this assignment.

Tiger Mou