Folds paper to create an ellipse and hyperbole.

On my honor I did not give or receive unauthorized aid on this assignment.

Tiger Mou