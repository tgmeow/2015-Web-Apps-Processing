Draws a triangle moving in the shape of an epichoiloid but now uses sliders to change the value of some variables.

On my honor I did not give or receive unauthorized aid on this assignment.

Tiger Mou