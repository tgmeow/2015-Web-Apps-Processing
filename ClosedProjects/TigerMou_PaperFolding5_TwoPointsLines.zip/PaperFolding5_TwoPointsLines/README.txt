Folds paper to put two points onto two lines and creates a triangly shape.

On my honor I did not give or receive unauthorized aid on this assignment.

Tiger Mou