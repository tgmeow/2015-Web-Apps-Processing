Draws an epitrochoid using a circle and the mouse position/distance from the center as a variable.

On my honor I did not give or receive unauthorized aid on this assignment.

Tiger Mou